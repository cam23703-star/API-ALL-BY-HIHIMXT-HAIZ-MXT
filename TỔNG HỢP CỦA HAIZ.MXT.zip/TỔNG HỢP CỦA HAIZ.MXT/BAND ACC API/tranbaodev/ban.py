import socket
import json
import time
import base64
import sys
import os
import requests
import threading
from tranbaodev.lib import *
from tranbaodev.GPackGEN import *
from tranbaodev.ReQAPI import *

class FreeFireLogin:
    def __init__(self):
        self.botid = None
        self.nickname = None
        self.region = None
        self.token = None
        self.ChatIP = None
        self.OnlineIP = None
        self.OnlinePort = None
        self.ChatPort = None
        self.key = None
        self.iv = None
        self.base_url = None
        self.packetAuth = None
        self.AuthenCode = None
        self.GuildIds = None
        self.running = False
        self.sock39699 = None
        self.sock39801 = None
        self._gen = None
        self._bot = None
        self.token_valid = False
        
    def check_token_api(self, access_token):
        """Kiểm tra token qua API Garena"""
        try:
            url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if "error" not in data:
                    return True, "Token hợp lệ", data
                else:
                    return False, f"Token không hợp lệ: {data.get('error')}", None
            else:
                return False, f"Lỗi API: {response.status_code}", None
                
        except Exception as e:
            return False, f"Lỗi kiểm tra: {str(e)}", None
    
    def login(self, access_token):
        """Đăng nhập vào FreeFire bằng access token"""
        try:
            print(f"[*] Đang Khóa Tài Khoản...")
            
            # Gọi API lấy thông tin
            data = FreeFireAPI().get(access_token, is_emulator=False)
            
            if "account not found" in data:
                return {"status": False, "message": "Account not found"}
            
            # Lấy thông tin cơ bản
            self.botid = int(data["UserAccountUID"])
            self.token = data["UserAuthToken"]
            self.region = str(data["LockRegion"])
            self.base_url = data["BaseUrl"]
            
            # Lấy thông tin server
            self.ChatIP = data["GameServerAddress"]["chatip"]
            self.OnlineIP = data["GameServerAddress"]["onlineip"]
            self.OnlinePort = data["GameServerAddress"]["onlineport"]
            self.ChatPort = data["GameServerAddress"]["chatport"]
            
            # Lấy key và iv
            self.key = bytes(data["key"])
            self.iv = bytes(data["iv"])
            
            # Lấy packet auth
            self.packetAuth = bytes(data["UserAuthPacket"])
            
            # Lấy nickname
            try:
                self.nickname = data.get("logindata", {}).get("4")
                if not self.nickname:
                    raise Exception("Empty nickname")
            except:
                try:
                    raw = data.get("UserNickName", "")
                    self.nickname = base64.b64decode(raw).decode("utf-8", errors="ignore")
                except:
                    self.nickname = "Unknown"
            
            # Lấy guild info
            if data.get("GuildData"):
                self.AuthenCode = data.get("GuildData").get("secret_code")
                self.GuildIds = data.get("GuildData").get("id")
            
            # Khởi tạo packet generator
            self._gen = TAO_PACKET(data["logindata"], data)
            self._bot = self.bot_session(self)
            
            self.token_valid = True
            
            return {
                "status": True,
                "data": {
                    "uid": self.botid,
                    "nickname": self.nickname,
                    "region": self.region,
                    "guild_id": self.GuildIds,
                    "chat_ip": self.ChatIP,
                    "chat_port": self.ChatPort,
                    "online_ip": self.OnlineIP,
                    "online_port": self.OnlinePort,
                    "base_url": self.base_url
                }
            }
            
        except Exception as e:
            return {"status": False, "message": str(e)}
    
    def monitor_token(self, access_token, check_interval=300):
        """Giám sát token định kỳ"""
        print(f"[*] Bắt đầu giám sát token (mỗi {check_interval//60} phút)")
        
        while self.running and self.token_valid:
            try:
                time.sleep(check_interval)
                
                if not self.running:
                    break
                
                print("[*] Đang kiểm tra token...")
                valid, msg, info = self.check_token_api(access_token)
                
                if not valid:
                    print(f"[!] Token không còn hiệu lực: {msg}")
                    self.token_valid = False
                    self.disconnect()
                    break
                else:
                    print("[✓] Token hợp lệ")
                    
            except Exception as e:
                print(f"[!] Lỗi: {e}")
    
    def connect_online(self):
        """Kết nối đến server Online"""
        if not self.OnlineIP or not self.OnlinePort:
            return False
        
        try:
            self.sock39699 = socket.create_connection(
                (self.OnlineIP, int(self.OnlinePort))
            )
            self.sock39699.sendall(self.packetAuth)
            self.running = True
            print(f"[✓] Online: {self.OnlineIP}:{self.OnlinePort}")
            return True
        except Exception as e:
            print(f"[!] Online lỗi: {e}")
            return False
    
    def connect_chat(self):
        """Kết nối đến server Chat"""
        if not self.ChatIP or not self.ChatPort:
            return False
        
        try:
            self.sock39801 = socket.create_connection(
                (self.ChatIP, int(self.ChatPort))
            )
            self.sock39801.sendall(self.packetAuth)
            
            if self.GuildIds and self.AuthenCode:
                self.sock39801.send(self._bot.join_channel(self.GuildIds, self.AuthenCode, 1))
                print(f"[✓] Guild: {self.GuildIds}")
            
            self.sock39801.send(self._bot.join_channel(None, None, 5))
            print(f"[✓] Chat: {self.ChatIP}:{self.ChatPort}")
            return True
        except Exception as e:
            print(f"[!] Chat lỗi: {e}")
            return False
    
    def disconnect(self):
        """Ngắt kết nối"""
        self.running = False
        self.token_valid = False
        
        for sock in [self.sock39699, self.sock39801]:
            try:
                if sock:
                    sock.shutdown(2)
                    sock.close()
            except:
                pass
        
        self.sock39699 = None
        self.sock39801 = None
        print("[✓] Đã ngắt kết nối")
    
    def send_keep_alive(self):
        """Gửi gói tin giữ kết nối"""
        try:
            if self.sock39699:
                self.sock39699.send(bytes([0, 2, 0, 1]))
        except:
            pass
    
    def run(self, access_token):
        """Chạy bot và giữ kết nối"""
        # Đăng nhập
        result = self.login(access_token)
        
        if not result["status"]:
            print(f"\n[✗] {result['message']}")
            return False
        
        # In thông tin
        print("\n" + "="*50)
        print("[✓] KHÓA TÀI KHOẢN VĨNH VIỄN THÀNH CÔNG")
        print("="*50)
        print(f"  UID      : {self.botid}")
        print(f"  Tên      : {self.nickname}")
        print(f"  Khu vực  : {self.region}")
        if self.GuildIds:
            print(f"  Guild ID : {self.GuildIds}")
        print(f"  Server   : {self.OnlineIP}:{self.OnlinePort}")
        print("="*50)
        
        # Kết nối
        self.connect_online()
        self.connect_chat()
        
        # Giám sát token
        monitor = threading.Thread(target=self.monitor_token, args=(access_token, 300))
        monitor.daemon = True
        monitor.start()
        
        print("\n[*] Bot đang chạy... (Ctrl+C để dừng)")
        
        # Vòng lặp chính
        try:
            while self.running and self.token_valid:
                self.send_keep_alive()
                time.sleep(25)
        except KeyboardInterrupt:
            print("\n[*] Đang dừng...")
        finally:
            self.disconnect()
            print("[✓] Đã dừng bot")
        
        return True
    
    class bot_session:
        def __init__(self, parent):
            self.par = parent
            
        def __getattr__(self, name):
            return getattr(self.par._gen, name)
        
        def reply(self, Id, Tp, Ms):
            try:
                if self.par.running and self.par.sock39801:
                    self.par.sock39801.sendall(
                        self.par._gen.send_message(Ms, Tp, Id)
                    )
            except:
                pass


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    banner = """
╔══════════════════════════════════════════╗
║     KHÓA TÀI KHOẢN VĨNH VIỄN        ║
║     CÂN NHẮC TRƯỚC KHI SỬ DỤNG    ║
║     VUI LÒNG GỬI ACCESS TOKEN       ║
║     TOOL BY DUCMINHDEV               ║
╚══════════════════════════════════════════╝
    """
    print(banner)

def main():
    clear_screen()
    print_banner()
    
    # Kiểm tra tham số
    if len(sys.argv) > 1:
        token = sys.argv[1]
        client = FreeFireLogin()
        client.run(token)
        return
    
    # Nhập token
    token = input("[?] Nhập Access Token: ").strip()
    
    if not token:
        print("[!] Token không được để trống!")
        return
    
    client = FreeFireLogin()
    client.run(token)

if __name__ == "__main__":
    main()
import requests
import urllib3
import base64
import json
import shutil
import GenerateNickname_pb2
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

FIXED_JWT = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjEiLCJ0eXAiOiJKV1QifQ.eyJhY2NvdW50X2lkIjoxNTQ5MDUxMjMxNSwibmlja25hbWUiOiJaQ3QrZG5adkxZSGpqb2JuM0lhNGg5UG5nYURXIiwibm90aV9yZWdpb24iOiJCRCIsImxvY2tfcmVnaW9uIjoiQkQiLCJleHRlcm5hbF9pZCI6IjliYWQyMzJkODY2ZjgwNGIzYmE5ZTUxODFkNDU4Zjk5IiwiZXh0ZXJuYWxfdHlwZSI6NCwicGxhdF9pZCI6MSwiY2xpZW50X3ZlcnNpb24iOiIxLjEyMy4xIiwiZW11bGF0b3Jfc2NvcmUiOjEwMCwiaXNfZW11bGF0b3IiOnRydWUsImNvdW50cnlfY29kZSI6Ik5QIiwiZXh0ZXJuYWxfdWlkIjo0NzQzNDYwMDUyLCJyZWdfYXZhdGFyIjoxMDIwMDAwMDcsInNvdXJjZSI6MCwibG9ja19yZWdpb25fdGltZSI6MCwiY2xpZW50X3R5cGUiOjIsInNpZ25hdHVyZV9tZDUiOiI3NDI4YjI1M2RlZmMxNjQwMThjNjA0YTFlYmJmZWJkZiIsInVzaW5nX3ZlcnNpb24iOjEsInJlbGVhc2VfY2hhbm5lbCI6ImFuZHJvaWQiLCJyZWxlYXNlX3ZlcnNpb24iOiJPQjUzIiwiZXhwIjoxNzc3MDQ4MTg5fQ.dh-dgjMhXvSvUOcJNYTr9PfeHzof3Bd4lMvM9REqm6s"

URL = "https://loginbp.ggpolarbear.com/GenerateNickname"
LANGUAGE = "en-US"

KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

session = requests.Session()

def print_center(text):
    cols = shutil.get_terminal_size((80, 20)).columns
    print(text.center(cols))

def encrypt_payload(data):
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    return cipher.encrypt(pad(data, AES.block_size))

def extract_openid_from_jwt(token):
    try:
        payload_part = token.split('.')[1]
        missing_padding = len(payload_part) % 4
        if missing_padding: payload_part += '=' * (4 - missing_padding)
        return json.loads(base64.b64decode(payload_part)).get("external_id")
    except: return None

def main():
    open_id = extract_openid_from_jwt(FIXED_JWT)
    if not open_id:
        print("❌ Invalid JWT")
        return

    try:
        count = int(input("How many nicknames? "))
    except: return

    session.headers.update({
        "Authorization": f"Bearer {FIXED_JWT}",
        "Content-Type": "application/octet-stream",
        "ReleaseVersion": "OB53",
        "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "X-GA": "v1 1"
    })

    
    req = GenerateNickname_pb2.CSGenerateNicknameReq()
    req.language = LANGUAGE
    req.open_id = open_id
    raw_proto = req.SerializeToString()
    
    encrypted_data = encrypt_payload(raw_proto)

    for _ in range(count):
        try:
            resp = session.post(URL, data=encrypted_data, verify=False, timeout=5)
            
            if resp.status_code == 200:
                res_pb = GenerateNickname_pb2.CSGenerateNicknameRes()
                res_pb.ParseFromString(resp.content)
                print_center(res_pb.nickname)
            else:
                print(f"❌ Error: {resp.status_code}")
                break
        except:
            print("❌ Request failed")
            break

if __name__ == "__main__":
    main()
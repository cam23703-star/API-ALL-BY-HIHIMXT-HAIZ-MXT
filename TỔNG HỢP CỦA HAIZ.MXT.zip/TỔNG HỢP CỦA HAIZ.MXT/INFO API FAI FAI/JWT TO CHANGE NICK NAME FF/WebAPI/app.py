import requests
import json
import base64
import urllib3
import httpx
import asyncio
from flask import Flask, request, jsonify, render_template_string
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from urllib.parse import urlparse, parse_qs

import ChangeName_pb2
import my_pb2
import output_pb2

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'
USERAGENT = "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"

def encrypt_payload(data):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(data, AES.block_size))

def decode_jwt(token):
    try:
        parts = token.split('.')
        payload_part = parts[1]
        missing_padding = len(payload_part) % 4
        if missing_padding: payload_part += '=' * (4 - missing_padding)
        decoded = json.loads(base64.b64decode(payload_part))
        return decoded.get("lock_region"), decoded.get("account_id")
    except: return None, None

def get_server_url(region):
    if region == "IND": return "https://client.ind.freefiremobile.com"
    elif region in ["BR", "US", "SAC", "NA"]: return "https://client.us.freefiremobile.com"
    elif region in ["SG", "BD"]: return "https://loginbp.ggpolarbear.com"
    else: return "https://loginbp.ggblueshark.com"


async def convert_eat_to_access(eat_token):
    try:
        async with httpx.AsyncClient(verify=False) as client:
            url = f"https://api-otrss.garena.com/support/callback/?access_token={eat_token}"
            resp = await client.get(url, follow_redirects=False)
            if 300 <= resp.status_code < 400:
                loc = resp.headers.get("Location", "")
                params = parse_qs(urlparse(loc).query)
                return params.get("access_token", [None])[0], params.get("account_id", [None])[0]
    except: pass
    return None, None

async def convert_access_to_jwt(access_token, account_id=None):
    open_id = "0"
    if account_id:
        try:
            r = requests.post("https://topup.pk/api/auth/player_id_login", 
                             json={"app_id": 100067, "login_id": str(account_id)}, verify=False)
            open_id = r.json().get("open_id", "0")
        except: pass

    platforms = [8, 3, 4, 6, 5, 11, 13]
    for p in platforms:
        game_data = my_pb2.GameData()
        game_data.timestamp = "2026-12-05 18:15:32"
        game_data.version_code = "1.123.1"
        game_data.open_id = open_id
        game_data.access_token = access_token
        game_data.platform_type = p
        
        enc = encrypt_payload(game_data.SerializeToString())
        headers = {"X-GA": "v1 1", "ReleaseVersion": "OB53", "Content-Type": "application/octet-stream"}
        try:
            r = requests.post("https://loginbp.ggblueshark.com/MajorLogin", data=enc, headers=headers, verify=False, timeout=5)
            if r.status_code == 200:
                res_msg = output_pb2.Garena_420()
                res_msg.ParseFromString(r.content)
                if hasattr(res_msg, "token") and res_msg.token:
                    return res_msg.token
        except: continue
    return None

@app.route('/')
def index():
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="theme-color" content="#28a745"> <!-- Green Header for Chrome -->
        <title>Garena Nickname API</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f8f9fa; }
            .header { background: #28a745; color: white; padding: 40px 20px; text-align: center; }
            .container { max-width: 850px; margin: 30px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
            h2 { color: #28a745; margin-bottom: 15px; border-bottom: 2px solid #eee; padding-bottom: 5px; }
            .box { background: #f1f8f1; border-left: 5px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 4px; }
            code { background: #2d3436; color: #00ff00; padding: 4px 8px; border-radius: 4px; font-weight: bold; }
            p { margin: 10px 0; color: #555; }
            .badge { display: inline-block; padding: 3px 8px; background: #28a745; color: white; border-radius: 12px; font-size: 0.8em; margin-right: 5px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🏷️ Nickname Modifier API</h1>
            <p>High Performance Free Fire Utility</p>
        </div>
        <div class="container">
            <h2>📌 Supported Tokens</h2>
            <p>You can use <b>any</b> of the following token types. The API will auto-detect and convert them in the background.</p>
            <p><span class="badge">Eat Token</span> <span class="badge">Access Token</span> <span class="badge">JWT (Bearer)</span></p>

            <h2>🚀 API Usage Examples</h2>
            
            <div class="box">
                <p><b>1. Change with Name Change Card (0 Diamonds):</b></p>
                <code>GET /change?token={AnyToken}&use=card&newname=MyNewName</code>
            </div>

            <div class="box">
                <p><b>2. Change with Diamonds (390 Diamonds):</b></p>
                <code>GET /change?token={AnyToken}&use=diamond&newname=MyNewName</code>
            </div>

            <h2>📝 Parameters</h2>
            <p>• <code>token</code> : Your Eat Token, Access Token or JWT.</p>
            <p>• <code>use</code> : Set to <code>card</code> or <code>diamond</code>.</p>
            <p>• <code>newname</code> : The new nickname you want (Max 12 chars).</p>
        </div>
    </body>
    </html>
    ''')

@app.route('/change', methods=['GET'])
def change_api():
    raw_token = request.args.get('token')
    method = request.args.get('use')
    new_name = request.args.get('newname')

    if not raw_token or not new_name:
        return jsonify({"success": False, "message": "Missing required fields"}), 400

    final_jwt = None
    try:
        if raw_token.startswith("eyJ"):
            final_jwt = raw_token
        elif len(raw_token) > 150:
            access, acc_id = asyncio.run(convert_eat_to_access(raw_token))
            final_jwt = asyncio.run(convert_access_to_jwt(access, acc_id))
        else:
            final_jwt = asyncio.run(convert_access_to_jwt(raw_token))

        if not final_jwt:
            return jsonify({"success": False, "message": "Token conversion failed"}), 401

        region, _ = decode_jwt(final_jwt)
        url = f"{get_server_url(region)}/MajorModifyNickname"
        
        req = ChangeName_pb2.CSModifyNicknameReq()
        req.nickname = new_name
        req.use_card = True if method == 'card' else False

        headers = {
            "X-GA": "v1 1", "Authorization": f"Bearer {final_jwt}",
            "Content-Type": "application/octet-stream", "ReleaseVersion": "OB53",
            "User-Agent": USERAGENT
        }
        
        resp = requests.post(url, data=encrypt_payload(req.SerializeToString()), headers=headers, verify=False, timeout=10)
        
        if resp.status_code == 200:
            return jsonify({"success": True, "message": "Name changed", "new_name": new_name}), 200
        else:
            try: msg = resp.content.decode('utf-8').strip()
            except: msg = f"Garena Error {resp.status_code}"
            return jsonify({"success": False, "message": msg}), 400

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

if __name__ == '__main__':
    app.run()
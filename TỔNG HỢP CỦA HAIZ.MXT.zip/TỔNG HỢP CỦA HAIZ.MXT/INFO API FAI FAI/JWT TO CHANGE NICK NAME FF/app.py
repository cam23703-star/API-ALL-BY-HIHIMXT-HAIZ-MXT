import requests
import json
import base64
import urllib3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from google.protobuf.json_format import MessageToJson
import ChangeName_pb2

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

def encrypt_payload(data):
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    return cipher.encrypt(pad(data, AES.block_size))

def get_server_url(region):
    if region == "IND": return "https://client.ind.freefiremobile.com"
    elif region in ["BR", "US", "SAC", "NA"]: return "https://client.us.freefiremobile.com"
    elif region in ["SG", "BD"]: return "https://loginbp.ggpolarbear.com"
    else: return "https://loginbp.ggpolarbear.com"

def decode_jwt(token):
    try:
        parts = token.split('.')
        payload = parts[1]
        missing_padding = len(payload) % 4
        if missing_padding: payload += '=' * (4 - missing_padding)
        decoded = json.loads(base64.b64decode(payload))
        return decoded.get("lock_region")
    except: return None

def main():
    print("\n" + "="*40)

    jwt_token = input("\n🔑 Enter JWT Token: ").strip()
    region = decode_jwt(jwt_token)
    
    if not region:
        print("❌ Invalid JWT Token!")
        return

    print(f"📍 Detected Region: {region}")
    
    new_name = input("🏷️ Enter New Nickname: ").strip()
    print("\nSelect Method:")
    print("1: Use Name Change Card")
    print("2: Use 390 Diamonds")
    method_choice = input("Choice (1 or 2): ").strip()

    req = ChangeName_pb2.CSModifyNicknameReq()
    req.nickname = new_name
    req.use_card = True if method_choice == '1' else False

    serialized_req = req.SerializeToString()
    encrypted_data = encrypt_payload(serialized_req)

    url = f"{get_server_url(region)}/MajorModifyNickname"
    headers = {
        "X-GA": "v1 1",
        "Authorization": f"Bearer {jwt_token}",
        "Content-Type": "application/octet-stream",
        "ReleaseVersion": "OB53",
        "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"
    }
    
    try:
        resp = requests.post(url, data=encrypted_data, headers=headers, verify=False, timeout=10)
        
        print("\n" + "-"*40)
        print(f"📡 Response Status: {resp.status_code}")
        
        print(f"📦 Raw Response Hex:\n{resp.content.hex().upper()}")
        print("-" * 40)

        if resp.status_code == 200:
            res_pb = ChangeName_pb2.CSModifyNicknameRes()
            res_pb.ParseFromString(resp.content)
            
            print("\n✅ SUCCESS! Nickname Updated.")
            print(MessageToJson(res_pb, preserving_proto_field_name=True))
        else:
            print("\n❌ GARENA ERROR DETECTED:")
            try:
                print(f"Message: {resp.content.decode('utf-8').strip()}")
            except:
                print("Unknown Error (Check Hex Above)")

    except Exception as e:
        print(f"\n💥 Connection Error: {e}")

    print("\n" + "="*40)

if __name__ == "__main__":
    main()
# Developed By AbdeeLkarim Amiri
# Refactored into an API by Gemini (v4 with full speed/count control)

import requests, os, psutil, sys, jwt, json, time, urllib3, xKEys, re, socket, threading
from protobuf_decoder.protobuf_decoder import Parser
from sponge import *
from sponge import xSendTeamMsg, Auth_Chat
from xHeaders import *
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
from threading import Thread
from flask import Flask, request, jsonify

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Global dictionary to hold all active client instances ---
clients = {}

def AuTo_ResTartinG():
    """Restarts the script every 6 hours to keep it fresh."""
    time.sleep(6 * 60 * 60)
    print('\n - AuTo ResTartinG The BoT ... ! ')
    try:
        p = psutil.Process(os.getpid())
        for handler in p.open_files() + p.connections():
            os.close(handler.fd)
    except Exception as e:
        print(f" - Error closing files/connections: {e}")
    
    python = sys.executable
    os.execl(python, python, *sys.argv)

def ResTarT_BoT():
    """Force restarts the script immediately."""
    print('\n - ResTartinG The BoT ... ! ')
    try:
        p = psutil.Process(os.getpid())
        for handler in p.open_files() + p.connections():
            os.close(handler.fd)
    except Exception:
        pass
    python = sys.executable
    os.execl(python, python, *sys.argv)

# Start the automatic restart thread
Thread(target=AuTo_ResTartinG, daemon=True).start()

class FF_CLient():
    def __init__(self, user_id, password):
        self.id = user_id
        self.password = password
        self.is_initialized = False
        
        # --- Attributes to be populated by initialize_client ---
        self.AutH_ToKen = None
        self.key = None
        self.iv = None
        self.ip = None
        self.port = None
        self.ip2 = None
        self.port2 = None

        self.initialize_client()
        
    def do_join_leave_spam(self, team_code, count, delay):
        """Connects, then repeatedly joins and leaves a team with a specific delay."""
        if not self.is_initialized:
            print(f"Client {self.id}: ERROR - Attempted to run command while not initialized.")
            return {"status": "error", "message": "Client not initialized."}

        cliEnts, cliEnts2 = None, None
        try:
            print(f"Client {self.id}: [SPAM] Task started for team {team_code}, repeating {count} times with a {delay}s delay.")
            cliEnts = socket.create_connection((self.ip, int(self.port)), timeout=10)
            cliEnts2 = socket.create_connection((self.ip2, int(self.port2)), timeout=10)
            print(f"Client {self.id}: [SPAM] Sockets connected.")

            cliEnts.send(bytes.fromhex(self.AutH_ToKen))
            cliEnts2.send(bytes.fromhex(self.AutH_ToKen))
            cliEnts.recv(1024)
            print(f"Client {self.id}: [SPAM] Authenticated.")

            for i in range(count):
                print(f"Client {self.id}: [SPAM] Join attempt {i + 1}/{count}")
                cliEnts2.send(GenJoinSquadsPacket(team_code, self.key, self.iv))
                
                try:
                    cliEnts2.settimeout(0.5)
                    cliEnts2.recv(99999)
                except socket.timeout:
                    pass 
                
                time.sleep(delay) # Use the delay from the URL

                print(f"Client {self.id}: [SPAM] Leave attempt {i + 1}/{count}")
                cliEnts2.send(ExiT('000000', self.key, self.iv))
                time.sleep(delay) # Use the delay from the URL

            return {"status": "success", "message": f"Completed {count} join/leave cycles."}

        except Exception as e:
            print(f"Client {self.id}: [SPAM] An unexpected error occurred: {e}")
            return {"status": "error", "message": str(e)}
        finally:
            print(f"Client {self.id}: [SPAM] Task finished. Closing connections.")
            if cliEnts: cliEnts.close()
            if cliEnts2: cliEnts2.close()

    def do_ghost(self, team_code, ghost_name):
        """Connects, sends ghosts, and disconnects."""
        if not self.is_initialized:
            print(f"Client {self.id}: ERROR - Attempted to run command while not initialized.")
            return {"status": "error", "message": "Client not initialized."}
        
        cliEnts, cliEnts2 = None, None
        try:
            print(f"Client {self.id}: [GHOST] Task started for team {team_code}.")
            cliEnts = socket.create_connection((self.ip, int(self.port)), timeout=10)
            cliEnts2 = socket.create_connection((self.ip2, int(self.port2)), timeout=10)
            print(f"Client {self.id}: [GHOST] Sockets connected.")

            cliEnts.send(bytes.fromhex(self.AutH_ToKen))
            cliEnts2.send(bytes.fromhex(self.AutH_ToKen))
            cliEnts.recv(1024)
            print(f"Client {self.id}: [GHOST] Authenticated.")

            response_data = {}
            def listen_on_socket2(sock, data_dict):
                try:
                    sock.settimeout(10.0)
                    data_dict['DaTa2'] = sock.recv(99999)
                except Exception as e:
                    print(f"Client {self.id}: [GHOST] Listener thread error: {e}")
                    data_dict['DaTa2'] = b''
            
            listener_thread = threading.Thread(target=listen_on_socket2, args=(cliEnts2, response_data))
            listener_thread.start()
            
            print(f"Client {self.id}: [GHOST] Sending join team packet...")
            cliEnts2.send(GenJoinSquadsPacket(team_code, self.key, self.iv))
            listener_thread.join(timeout=11.0)
            
            DaTa2_hex = response_data.get('DaTa2', b'').hex()
            print(f"Client {self.id}: [GHOST] Received team join response (HEX): {DaTa2_hex[:40]}...")

            if '0500' in DaTa2_hex[0:4]:
                print(f"Client {self.id}: [GHOST] Join successful. Preparing to send ghosts.")
                dT = json.loads(DeCode_PackEt(DaTa2_hex[10:]))
                idT = dT["5"]["data"]["1"]["data"]
                sq = dT["5"]["data"]["31"]["data"]
                cliEnts2.send(ExiT('000000', self.key, self.iv))
                time.sleep(0.5)
                for i in range(3):
                    cliEnts2.send(ghost_pakcet(idT, ghost_name, sq, self.key, self.iv))
                    print(f"Client {self.id}: [GHOST] Sent ghost {i+1}/3")
                    time.sleep(0.1)
                return {"status": "success", "message": "Ghost command successful."}
            else:
                print(f"Client {self.id}: [GHOST] Join FAILED. Server response did not contain '0500'.")
                return {"status": "error", "message": f"Failed to join team. Response: {DaTa2_hex}"}
        except Exception as e:
            print(f"Client {self.id}: [GHOST] An unexpected error occurred: {e}")
            return {"status": "error", "message": str(e)}
        finally:
            print(f"Client {self.id}: [GHOST] Task finished. Closing connections.")
            if cliEnts: cliEnts.close()
            if cliEnts2: cliEnts2.close()
            
    def do_msg(self, team_code, message):
        """Connects, sends a message, and disconnects."""
        if not self.is_initialized:
            return {"status": "error", "message": "Client not initialized."}

        cliEnts, cliEnts2 = None, None
        try:
            print(f"Client {self.id}: [MSG] Task started for team {team_code}.")
            cliEnts = socket.create_connection((self.ip, int(self.port)), timeout=10)
            cliEnts2 = socket.create_connection((self.ip2, int(self.port2)), timeout=10)
            print(f"Client {self.id}: [MSG] Sockets connected.")

            cliEnts.send(bytes.fromhex(self.AutH_ToKen))
            cliEnts2.send(bytes.fromhex(self.AutH_ToKen))
            cliEnts.recv(1024)
            print(f"Client {self.id}: [MSG] Authenticated.")

            response_data = {}
            def listen_on_socket2(sock, data_dict):
                try:
                    sock.settimeout(10.0)
                    data_dict['DaTa2'] = sock.recv(99999)
                except Exception as e:
                    print(f"Client {self.id}: [MSG] Listener thread error: {e}")
                    data_dict['DaTa2'] = b''
            
            listener_thread = threading.Thread(target=listen_on_socket2, args=(cliEnts2, response_data))
            listener_thread.start()

            print(f"Client {self.id}: [MSG] Sending join team packet...")
            cliEnts2.send(GenJoinSquadsPacket(team_code, self.key, self.iv))
            listener_thread.join(timeout=11.0)

            DaTa2_hex = response_data.get('DaTa2', b'').hex()
            print(f"Client {self.id}: [MSG] Received team join response (HEX): {DaTa2_hex[:40]}...")

            if '0500' in DaTa2_hex[0:4]:
                print(f"Client {self.id}: [MSG] Join successful. Preparing to send messages.")
                dT = json.loads(DeCode_PackEt(DaTa2_hex[10:]))
                idT = dT["5"]["data"]["1"]["data"]
                sq = dT["5"]["data"]["14"]["data"]
                cliEnts.send(Auth_Chat(idT, sq, self.key, self.iv))
                time.sleep(0.5)
                
                message_count = 50
                for i in range(message_count):
                    msg_to_send = f"[b][c][{ArA_CoLor()}] {message}"
                    cliEnts.send(xSendTeamMsg(msg_to_send, idT, self.key, self.iv))
                    time.sleep(0.2)
                print(f"Client {self.id}: [MSG] Sent {message_count} messages.")
                
                cliEnts2.send(ExiT('000000', self.key, self.iv))
                return {"status": "success", "message": f"Sent {message_count} messages."}
            else:
                print(f"Client {self.id}: [MSG] Join FAILED. Server response did not contain '0500'.")
                return {"status": "error", "message": f"Failed to join team. Response: {DaTa2_hex}"}
        except Exception as e:
            print(f"Client {self.id}: [MSG] An unexpected error occurred: {e}")
            return {"status": "error", "message": str(e)}
        finally:
            print(f"Client {self.id}: [MSG] Task finished. Closing connections.")
            if cliEnts: cliEnts.close()
            if cliEnts2: cliEnts2.close()

    def initialize_client(self):
        """Gets all connection tokens and details without starting a listening loop."""
        try:
            details = self.Guest_GeneRaTe(self.id, self.password)
            if not details:
                raise Exception("Failed to get connection details from Guest_GeneRaTe.")

            token, self.key, self.iv, timestamp, self.ip, self.port, self.ip2, self.port2 = details
            
            AfTer_DeC_JwT = jwt.decode(token, options={"verify_signature": False})
            AccounT_Uid = AfTer_DeC_JwT.get('account_id')
            EncoDed_AccounT = hex(AccounT_Uid)[2:]
            HeX_VaLue = DecodE_HeX(timestamp)
            TimE_HEx = HeX_VaLue
            JwT_ToKen_ = token.encode().hex()

            Header = hex(len(EnC_PacKeT(JwT_ToKen_, self.key, self.iv)) // 2)[2:]
            length = len(EncoDed_AccounT)
            __ = '0' * (16 - length)
            Header = f'0115{__}{EncoDed_AccounT}{TimE_HEx}00000{Header}'
            FiNal_ToKen_0115 = Header + EnC_PacKeT(JwT_ToKen_, self.key, self.iv)
            
            self.AutH_ToKen = FiNal_ToKen_0115
            self.is_initialized = True
            print(f"--- Client for ID: {self.id} initialized successfully! ---")
        except Exception as e:
            print(f"--- Could not initialize client {self.id}. Error: {e} ---")
            self.is_initialized = False

    # --- Authentication and Connection Helpers (Internal) ---
    def GeT_Key_Iv(self, serialized_data):
        my_message = xKEys.MyMessage()
        my_message.ParseFromString(serialized_data)
        timestamp, key, iv = my_message.field21, my_message.field22, my_message.field23
        timestamp_obj = Timestamp()
        timestamp_obj.FromNanoseconds(timestamp)
        timestamp_seconds = timestamp_obj.seconds
        timestamp_nanos = timestamp_obj.nanos
        combined_timestamp = timestamp_seconds * 1_000_000_000 + timestamp_nanos
        return combined_timestamp, key, iv

    def Guest_GeneRaTe(self, uid, password):
        url = "https://100067.connect.garena.com/oauth/guest/token/grant"
        headers = {"Host": "100067.connect.garena.com", "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)", "Content-Type": "application/x-www-form-urlencoded", "Accept-Encoding": "gzip, deflate, br", "Connection": "close",}
        dataa = {"uid": f"{uid}", "password": f"{password}", "response_type": "token", "client_type": "2", "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3", "client_id": "100067",}
        try:
            response = requests.post(url, headers=headers, data=dataa).json()
            Access_ToKen, Access_Uid = response['access_token'], response['open_id']
            print(f" - Uid : {uid}")
            print(f' - Access Token : {Access_ToKen[:15]}...')
            return self.ToKen_GeneRaTe(Access_ToKen, Access_Uid)
        except Exception as e:
            print(f"Error in Guest_GeneRaTe for {uid}: {e}")
            return None

    def GeT_LoGin_PorTs(self, JwT_ToKen, PayLoad):
        UrL = 'https://clientbp.ggpolarbear.com/GetLoginData'
        HeadErs = {'Expect': '100-continue', 'Authorization': f'Bearer {JwT_ToKen}', 'X-Unity-Version': '2018.4.11f1', 'X-GA': 'v1 1', 'ReleaseVersion': 'OB52', 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)', 'Host': 'clientbp.ggpolarbear.com', 'Connection': 'close', 'Accept-Encoding': 'gzip, deflate, br',}
        Res = requests.post(UrL, headers=HeadErs, data=PayLoad, verify=False)
        BesTo_data = json.loads(DeCode_PackEt(Res.content.hex()))
        address, address2 = BesTo_data['32']['data'], BesTo_data['14']['data']
        ip, ip2 = address[:-6], address2[:-6]
        port, port2 = address[-5:], address2[-5:]
        return ip, port, ip2, port2

    def ToKen_GeneRaTe(self, Access_ToKen, Access_Uid):
        UrL = "https://loginbp.ggpolarbear.com/MajorLogin"
        HeadErs = {'X-Unity-Version': '2018.4.11f1', 'ReleaseVersion': 'OB52', 'Content-Type': 'application/x-www-form-urlencoded', 'X-GA': 'v1 1', 'Content-Length': '928', 'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)', 'Host': 'loginbp.ggpolarbear.com', 'Connection': 'Keep-Alive', 'Accept-Encoding': 'gzip'}
        dT = bytes.fromhex('1a13323032352d31312d32362030313a35313a3238220966726565206669726528013a07312e3132302e314232416e64726f6964204f532039202f204150492d3238202850492f72656c2e636a772e32303232303531382e313134313333294a0848616e6468656c64520c4d544e2f537061636574656c5a045749464960800a68d00572033234307a2d7838362d3634205353453320535345342e3120535345342e32204156582041565832207c2032343030207c20348001e61e8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e329a012b476f6f676c657c36323566373136662d393161372d343935622d396631362d303866653964336336353333a2010e3137362e32382e3133392e313835aa01026172b201203433303632343537393364653836646134323561353263616164663231656564ba010134c2010848616e6468656c64ca010d4f6e65506c7573204135303130ea014063363961653230386661643732373338623637346232383437623530613361316466613235643161313966616537343566633736616334613065343134633934f00101ca020c4d544e2f537061636574656cd2020457494649ca03203161633462383065636630343738613434323033626638666163363132306635e003b5ee02e8039a8002f003af13f80384078004a78f028804b5ee029004a78f029804b5ee02b00404c80401d2043d2f646174612f6170702f636f6d2e6474732e667265656669726574682d66705843537068495636644b43376a4c2d574f7952413d3d2f6c69622f61726de00401ea045f65363261623933353464386662356662303831646233333861636233333439317c2f646174612f6170702f636f6d2e6474732e667265656669726574682d66705843537068495636644b43376a4c2d574f7952413d3d2f626173652e61706bf00406f804018a050233329a050a32303139313139303236a80503b205094f70656e474c455332b805ff01c00504e005be7eea05093372645f7061727479f205704b717348543857393347646347335a6f7a454e6646775648746d377171316552554e6149444e67526f626f7a4942744c4f695943633459367a767670634943787a514632734f453463627974774c7334785a62526e70524d706d5752514b6d654f35766373386e51594268777148374bf805e7e4068806019006019a060134a2060134b2062213521146500e590349510e460900115843395f005b510f685b560a6107576d0f0366')
        dT = dT.replace(b'2026-01-14 12:19:02', str(datetime.now())[:-7].encode())
        dT = dT.replace(b'c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94', Access_ToKen.encode())
        dT = dT.replace(b'4306245793de86da425a52caadf21eed', Access_Uid.encode())
        PaYload = bytes.fromhex(EnC_AEs(dT.hex()))
        ResPonse = requests.post(UrL, headers=HeadErs, data=PaYload, verify=False)
        if ResPonse.status_code == 200 and len(ResPonse.text) > 10:
            BesTo_data = json.loads(DeCode_PackEt(ResPonse.content.hex()))
            JwT_ToKen = BesTo_data['8']['data']
            combined_timestamp, key, iv = self.GeT_Key_Iv(ResPonse.content)
            ip, port, ip2, port2 = self.GeT_LoGin_PorTs(JwT_ToKen, PaYload)
            return JwT_ToKen, key, iv, combined_timestamp, ip, port, ip2, port2
        return None

# ==============================================================================
# --- API SERVER DEFINITION (Accepts GET requests from browser) ---
# ==============================================================================

app = Flask(__name__)

def run_command_in_parallel(command_func, *args):
    """Helper function to run a client command on all clients in parallel."""
    results = {}
    threads = []

    def task_wrapper(client_id, client_obj):
        results[client_id] = command_func(client_obj, *args)

    for client_id, client in clients.items():
        thread = threading.Thread(target=task_wrapper, args=(client_id, client))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()
    
    return results

@app.route('/api/spam', methods=['GET'])
def handle_spam():
    data = request.args
    if 'code' not in data:
        return jsonify({"status": "error", "message": "Missing 'code' parameter in URL."}), 400

    team_code = data['code']
    try:
        # Control the number of repetitions (default: 500)
        count = int(data.get('count', 999))
        # Control the speed/delay in seconds (default: 0.5s)
        delay = float(data.get('delay', 0.001))
    except ValueError:
        return jsonify({"status": "error", "message": "'count' or 'delay' must be a number."}), 400

    # Enforce a minimum delay of 0.1s to prevent getting blocked
    if delay < 0.001:
        delay = 0.001

    results = run_command_in_parallel(FF_CLient.do_join_leave_spam, team_code, count, delay)
    return jsonify({"status": "completed", "action": "spam", "results": results})

@app.route('/api/ghost', methods=['GET'])
def handle_ghost():
    data = request.args
    if 'code' not in data:
        return jsonify({"status": "error", "message": "Missing 'code' parameter in URL."}), 400

    team_code = data['code']
    ghost_name = data.get('name', "✚ＰнＡʀＭAＣıＥ✚")
    
    results = run_command_in_parallel(FF_CLient.do_ghost, team_code, ghost_name)
    return jsonify({"status": "completed", "action": "ghost", "results": results})

@app.route('/api/msg', methods=['GET'])
def handle_msg():
    data = request.args
    if 'code' not in data or 'message' not in data:
        return jsonify({"status": "error", "message": "Missing 'code' and 'message' parameters in URL."}), 400

    team_code = data['code']
    message = data['message']

    results = run_command_in_parallel(FF_CLient.do_msg, team_code, message)
    return jsonify({"status": "completed", "action": "msg", "results": results})

def start_clients_and_api():
    """Initializes all accounts and starts the Flask API server."""
    
    # --- ضع معلومات حساباتك هنا ---
    ACCOUNTS = [
        {'id': '4336343252', 'password': 'XCXC_DB6WA_XC3_TOP_ONE_X5T25'},
        {'id': '4336343560', 'password': 'XCXC_U1MI1_XC3_TOP_ONE_VMY8W'},
        {'id': '4336343823', 'password': 'XCXC_EGJQH_XC3_TOP_ONE_3Q56T'},
        {'id': '4336344043', 'password': 'XCXC_I02N8_XC3_TOP_ONE_RYDME'},
                        
    ]

    print("--- Initializing clients... ---")
    for acc in ACCOUNTS:
        if not acc['password'] or 'PASSWORD' in acc['password']:
            print(f"!!! Skipping account {acc['id']} due to missing password.")
            continue
        client_instance = FF_CLient(acc['id'], acc['password'])
        if client_instance.is_initialized:
            clients[acc['id']] = client_instance
    
    if not clients:
        print("\n!!! CRITICAL: No clients were initialized. API server will not start. !!!")
        sys.exit(1)
        
    print(f"\n🚀 Total {len(clients)} clients connected and ready.")
    print(f"🚀 Starting API server on http://0.0.0.0:5000")
    print("   - Endpoint for ghosts: /api/ghost")
    print("   - Endpoint for messages: /api/msg")
    print("   - Endpoint for spamming: /api/spam (Params: code, count, delay)")
    app.run(host='0.0.0.0', port=3002)

if __name__ == "__main__":
    start_clients_and_api()

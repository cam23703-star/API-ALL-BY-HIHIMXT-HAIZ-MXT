#تطوير كامل من عمك مصري
#!/usr/bin/env python3
# bulk_name_changer_v2.py
# يقرأ accs.txt (uid:password) -> يجلب token من masry-jwt -> يغيّر الاسم عبر ff-nickname-change
# يتحقق من نجاح العملية عن طريق JSON 'status' == 'success'
#!/usr/bin/env python3
# bulk_name_changer_v2.py
import asyncio
import aiohttp
import async_timeout
import csv
import json
from pathlib import Path
from typing import List, Tuple

INPUT_FILE = "a.json"
OUTPUT_CSV = "results_console.csv"
JWT_ENDPOINT = "https://jwt-maker-danger.vercel.app/token"
NAME_CHANGE_ENDPOINT = "https://ff-nickname-change.onrender.com/name-change"
BASE_NAME = "BLRX_M9WD"
START_COUNTER = 1
SLEEP_BETWEEN = 0.0
RETRIES = 2
TIMEOUT = 15
CONCURRENCY = 50

def read_accs(path: str) -> List[Tuple[str, str]]:
    p = Path(path)
    if not p.exists():
        return []
    txt = p.read_text(encoding="utf-8").strip()
    accs = []
    try:
        j = json.loads(txt)
        if isinstance(j, dict):
            for k, v in j.items():
                accs.append((str(k), str(v)))
        elif isinstance(j, list):
            for item in j:
                if isinstance(item, str) and ":" in item:
                    uid, pwd = item.split(":", 1)
                    accs.append((uid, pwd))
                elif isinstance(item, dict):
                    uid = item.get("uid") or item.get("id") or item.get("external_uid")
                    pwd = item.get("password") or item.get("pwd")
                    if uid and pwd:
                        accs.append((str(uid), str(pwd)))
        if accs:
            return accs
    except:
        pass
    for l in txt.splitlines():
        l = l.strip()
        if ":" in l:
            uid, pwd = l.split(":", 1)
            accs.append((uid, pwd))
    return accs

async def fetch_json(session: aiohttp.ClientSession, url: str, params: dict = None, timeout: int = TIMEOUT):
    for attempt in range(RETRIES + 1):
        try:
            with async_timeout.timeout(timeout):
                async with session.get(url, params=params) as resp:
                    text = await resp.text()
                    try:
                        return resp.status, json.loads(text), text
                    except:
                        return resp.status, None, text
        except Exception:
            if attempt < RETRIES:
                await asyncio.sleep(1)
            else:
                return 0, None, "exception"

async def get_jwt(session: aiohttp.ClientSession, uid: str, pwd: str):
    url = JWT_ENDPOINT
    params = {"uid": uid, "password": pwd}
    status, j, raw = await fetch_json(session, url, params)
    if j and isinstance(j, dict):
        token = j.get("token")
        decoded = j.get("decoded_token")
        if token:
            return token, decoded, json.dumps(j, ensure_ascii=False)
    return None, None, raw if raw else "Failed to get token"

async def change_name(session: aiohttp.ClientSession, token: str, new_name: str):
    url = NAME_CHANGE_ENDPOINT
    params = {"token": token, "name": new_name}
    status, j, raw = await fetch_json(session, url, params)
    if j and isinstance(j, dict):
        if str(j.get("status")).lower() == "success":
            return True, status, json.dumps(j, ensure_ascii=False)
        return False, status, json.dumps(j, ensure_ascii=False)
    else:
        txt = raw or ""
        ok = (status == 200 and "success" in txt.lower())
        return ok, status, txt

async def worker(idx: int, uid: str, pwd: str, session: aiohttp.ClientSession, sem: asyncio.Semaphore, counter_lock: asyncio.Lock, counter_ref: dict, results: list):
    async with sem:
        token, decoded, raw = await get_jwt(session, uid, pwd)
        async with counter_lock:
            new_name = f"{BASE_NAME}{counter_ref['val']}"
            counter_ref['val'] += 1
        if not token:
            status_icon = "❌"
            reason = raw
        else:
            ok, http_status, resp = await change_name(session, token, new_name)
            status_icon = "✅" if ok else "❌"
            reason = resp
        decoded_str = json.dumps(decoded, ensure_ascii=False) if decoded else ""
        results.append({
            "index": idx,
            "uid": uid,
            "password": pwd,
            "token": token or "",
            "decoded_token": decoded_str,
            "new_name": new_name,
            "status": status_icon,
            "reason": reason
        })
        if SLEEP_BETWEEN:
            await asyncio.sleep(SLEEP_BETWEEN)

async def main_async():
    accs = read_accs(INPUT_FILE)
    if not accs:
        return
    results = []
    sem = asyncio.Semaphore(CONCURRENCY)
    counter_lock = asyncio.Lock()
    counter_ref = {"val": START_COUNTER}
    conn = aiohttp.TCPConnector(limit=CONCURRENCY, ssl=False)
    timeout = aiohttp.ClientTimeout(total=None)
    async with aiohttp.ClientSession(connector=conn, timeout=timeout) as session:
        tasks = []
        for idx, (uid, pwd) in enumerate(accs, 1):
            tasks.append(worker(idx, uid, pwd, session, sem, counter_lock, counter_ref, results))
        await asyncio.gather(*tasks)
    results.sort(key=lambda x: x["index"])
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        for row in results:
            writer.writerow(row)

if __name__ == "__main__":
    asyncio.run(main_async())
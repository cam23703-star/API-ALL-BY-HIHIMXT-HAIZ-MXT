import json

INPUT_FILE = "accs.json"
OUTPUT_FILE = "output.json"

data = {}

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line or ":" not in line:
            continue

        uid, password = line.split(":", 1)
        data[uid] = password

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)

print("✅ Done! Saved full passwords to output.json")
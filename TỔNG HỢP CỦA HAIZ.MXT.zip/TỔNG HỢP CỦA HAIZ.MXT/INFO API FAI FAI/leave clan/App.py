from flask import Flask, jsonify
import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import LevCLan_pb2

app = Flask(__name__)

xK = bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56])
xV = bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])

@app.route('/ReqCLan/<uid>/<password>/<clan_id>', methods=['GET'])
def request_join_clan(uid, password, clan_id):
    try:
        JwTxOB51 = f"https://masry-jwt.vercel.app/get?uid={uid}&password={password}"
        jwt_response = requests.get(JwTxOB51)
        
        if jwt_response.status_code != 200:
            return jsonify({
                "Error =>": "GeT JwT ToKeN !"
            }), 400
        
        JwT = jwt_response.json()['jwt_token']
        
        msg = ReqCLan_pb2.MyMessage()
        msg.field_1 = int(clan_id)
        data = msg.SerializeToString()
        
        cipher = AES.new(xK, AES.MODE_CBC, xV)
        encrypted = cipher.encrypt(pad(data, AES.block_size))
        
        headers = {
            'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 10; m3 note Build/QD4A.200805.003)",
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/octet-stream",
            'Authorization': f"Bearer {JwT}",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': "OB51",
        }
        
        response = requests.post(
            "https://clientbp.ggpolarbear.com/QuitClan",
            headers=headers,
            data=encrypted
        )
        
        if response.status_code == 200:
            return jsonify({
                "STaTuS": "Successfully leave clan"
            })
        else:
            return jsonify({
                "STaTuS": "Failed to leave clan"
            }), 400
            
    except Exception as e:
        return jsonify({
            "Error =>": str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)